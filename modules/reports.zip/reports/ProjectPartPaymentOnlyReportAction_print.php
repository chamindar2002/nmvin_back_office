<?php 
 echo "olrig";
 
?>