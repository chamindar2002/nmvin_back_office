<?php 
 header('Location: index.php?m=reports&a=Reports'); 
?>