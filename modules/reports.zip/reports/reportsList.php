<?php
include('reportFunctions.php');

?>
<link rel="stylesheet" type="text/css" href="calendar/datepicker.css" /> 
<script type="text/javascript" src="calendar/datepicker.js"></script> 


<!--<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.js" type="text/javascript"></script>-->
<script type="text/javascript" src="themes/script/jquery.min.js"></script>
<script type='text/javascript'>
$(document).ready(function(){
	$(".span_rpt1").click(function(){
                $(".div_rpt8").slideUp(1000);
		$(".div_rpt7").slideUp(1000);
		$(".div_rpt6").slideUp(1000);
		$(".div_rpt5").slideUp(1000);
		$(".div_rpt4").slideUp(1000);
		$(".div_rpt3").slideUp(1000);
	    $(".div_rpt2").slideUp(1000);
		$(".div_rpt1").slideToggle("slow");	
	  });
});

$(document).ready(function(){
	$(".span_rpt2").click(function(){
                $(".div_rpt8").slideUp(1000);
		$(".div_rpt7").slideUp(1000);
		$(".div_rpt6").slideUp(1000);
		$(".div_rpt5").slideUp(1000);
		$(".div_rpt4").slideUp(1000);
		$(".div_rpt3").slideUp(1000);
	    $(".div_rpt2").slideToggle("slow");
	    $(".div_rpt1").slideUp(1000);
	  });
});

$(document).ready(function(){
	$(".span_rpt3").click(function(){
                $(".div_rpt8").slideUp(1000);
		$(".div_rpt7").slideUp(1000);
		$(".div_rpt6").slideUp(1000);
		$(".div_rpt5").slideUp(1000);
		$(".div_rpt4").slideUp(1000);
	    $(".div_rpt3").slideToggle("slow");
	    $(".div_rpt2").slideUp(1000);
	    $(".div_rpt1").slideUp(1000);
	  });
});


$(document).ready(function(){
	$(".span_rpt4").click(function(){
                $(".div_rpt8").slideUp(1000);
		$(".div_rpt7").slideUp(1000);
		$(".div_rpt6").slideUp(1000);
		$(".div_rpt5").slideUp(1000);
		$(".div_rpt4").slideToggle("slow");
	    $(".div_rpt3").slideUp(1000);
	    $(".div_rpt2").slideUp(1000);
	    $(".div_rpt1").slideUp(1000);
	  });
});


$(document).ready(function(){
	$(".span_rpt5").click(function(){
                $(".div_rpt8").slideUp(1000);
		$(".div_rpt7").slideUp(1000);
		$(".div_rpt6").slideUp(1000);
		$(".div_rpt5").slideToggle("slow");
		$(".div_rpt4").slideUp(1000);
	    $(".div_rpt3").slideUp(1000);
	    $(".div_rpt2").slideUp(1000);
	    $(".div_rpt1").slideUp(1000);
	  });
});


$(document).ready(function(){
		$(".span_rpt6").click(function(){
                $(".div_rpt8").slideUp(1000);
		$(".div_rpt7").slideUp(1000);	
		$(".div_rpt6").slideToggle("slow");	
		$(".div_rpt5").slideUp(1000);
		$(".div_rpt4").slideUp(1000);
	    $(".div_rpt3").slideUp(1000);
	    $(".div_rpt2").slideUp(1000);
	    $(".div_rpt1").slideUp(1000);
	  });
});

$(document).ready(function(){
        $(".div_rpt8").slideUp(1000);
	$(".span_rpt7").click(function(){
	$(".div_rpt7").slideToggle("slow");
	$(".div_rpt6").slideUp(1000);	
	$(".div_rpt5").slideUp(1000);
	$(".div_rpt4").slideUp(1000);
    $(".div_rpt3").slideUp(1000);
    $(".div_rpt2").slideUp(1000);
    $(".div_rpt1").slideUp(1000);
  });
});

$(document).ready(function(){
	$(".span_rpt8").click(function(){
        $(".div_rpt8").slideToggle("slow");    
        $(".div_rpt7").slideUp(1000);
	$(".div_rpt6").slideUp(1000);	
	$(".div_rpt5").slideUp(1000);
	$(".div_rpt4").slideUp(1000);
    $(".div_rpt3").slideUp(1000);
    $(".div_rpt2").slideUp(1000);
    $(".div_rpt1").slideUp(1000);
  });
});
</script>



<table class='formstable' border='0'>
	
<tr>
	<td>	
	<div id='div_searchbydrange'>
			
		<table width='100%' border='0'>

			<tr>
				<td>
<!--				+++++++++++++++++++++++++++++++++++++++collection report+++++++++++++++++++++++++++++++-->
					<form method="post" action="?m=reports&a=CollectionsReport" name='frmcollection_report' id='frmcollection_report'>
						<div class="span_rpt1" style="cursor:pointer;" id='spanrpt'><strong>&#8730; &nbsp;Collection Report</strong></div>
						<input type="hidden" name="rptcode1" id="rptcode1" value="R1">
					
						<div class="div_rpt1" style="display:none;">
							<table width='100%' border='0'>
								<tr><td><input type='hidden' name='searchby' id='searchby' value='drange'></td></tr>
								<tr><td>Search From</td></tr>
										
								<tr><td width="150">
										<input id="start_dt_rpt1" name="start_dt_rpt1" class='datepicker' size='11' value="" readonly="readonly" />
								</td></tr>
											
								<tr><td>Search To</td></tr>
											
								<tr><td>		
										<input id="end_dt_rpt1" name="end_dt_rpt1" class='datepicker' size='11' value=""; readonly="readonly" /> 			
								</td></tr>
								
								<tr><td>Select Project</td></tr>
								
								<tr><td>
										<?php printProjects3();?>
								</td></tr>
								
								<tr><td><input type='button' name='btn_rpt1' id='btn_rpt1' value='[l&#8801;l]' title='print' class='buttontype1' onclick='submitfrmrpt1()'></td></tr>
							</table>
						</div>
					</form>
<!--				++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++-->


<!--				++++++++++++++++++++++++++++++++++++payments overdue report+++++++++++++++++++++++++++-->
					<form method="post" action="?m=reports&a=PaymentsOverdueReport" name='frmoverdue_report' id='frmoverdue_report'>
						<div class="span_rpt2" style="cursor:pointer;" id='spanrpt'><strong>&#8730; &nbsp;Payements Overdue Report</strong></div>
						<input type="hidden" name="rptcode2" id="rptcode2" value="R2">
					
						<div class="div_rpt2" style="display:none;">
							<table width='100%' border='0'>
								<tr><td><input type='hidden' name='searchby' id='searchby' value='nofmonths'></td></tr>
								<tr><td>Months Overdue</td></tr>
										
								<tr><td width="150">
										<?php printMonths(3);?>
								</td></tr>
                                                                
                                                                <tr><td width="150">
										<?php printProjects("rptoverdue");?>
								</td></tr>
								
								<tr><td><input type='button' name='btn_rpt2' id='btn_rpt2' value='[l&#8801;l]' title='print' class='buttontype1' onclick='submitfrmrpt2()'></td></tr>
							</table>
						</div>
					</form>
<!--				++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++-->	


<!--				++++++++++++++++++++++++++++++++++++project summary report+++++++++++++++++++++++++++-->
					<form method="post" action="?m=reports&a=ProjectSummaryReport" name='frmprojectsummary_report' id='frmprojectsummary_report'>
						<div class="span_rpt3" style="cursor:pointer;" id='spanrpt'><strong>&#8730; &nbsp;Project Summary Report</strong></div>
						<input type="hidden" name="rptcode3" id="rptcode3" value="R3">
					
						<div class="div_rpt3" style="display:none;">
							<table width='100%' border='0'>
								<tr><td><input type='hidden' name='searchby' id='searchby' value='projectcode'></td></tr>
								<tr><td>Select Project</td></tr>
										
								<tr><td width="150">
										<?php printProjects("");?>
								</td></tr>
								
								<tr><td><input type='button' name='btn_rpt3' id='btn_rpt3' value='[l&#8801;l]' title='print' class='buttontype1' onclick='submitfrmrpt3()'></td></tr>
							</table>
						</div>
					</form>
<!--				++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++-->	


<!--				++++++++++++++++++++++++++++++++++++project summary details report+++++++++++++++++++++++++++-->
					<form method="post" action="?m=reports&a=ProjectSummaryDetailsReport" name='frmprojectsummarydetails_report' id='frmprojectsummarydetails_report'>
						<div class="span_rpt4" style="cursor:pointer;" id='spanrpt'><strong>&#8730; &nbsp;Project Summary Breakdown Report</strong></div>
						<input type="hidden" name="rptcode4" id="rptcode4" value="R4">
					
						<div class="div_rpt4" style="display:none;">
							<table width='100%' border='0'>
								<tr><td><input type='hidden' name='searchby' id='searchby' value='projectcode'></td></tr>
								<tr><td>Select Project</td></tr>
										
								<tr><td width="150">
										<?php printProjects("2");?>
								</td></tr>
								
								<tr><td><input type='button' name='btn_rpt4' id='btn_rpt4' value='[l&#8801;l]' title='print' class='buttontype1' onclick='submitfrmrpt4()'></td></tr>
							</table>
						</div>
					</form>
<!--				++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++-->	


<!--				++++++++++++++++++++++++++++++++++++part payment only report+++++++++++++++++++++++++++-->
					<form method="post" action="?m=reports&a=ProjectPartPaymentOnlyReport" name='frmprojectpponly_report' id='frmprojectpponly_report'>
						<div class="span_rpt5" style="cursor:pointer;" id='spanrpt'><strong>&#8730; &nbsp;Part Payment Only Report</strong></div>
						<input type="hidden" name="rptcode5" id="rptcode5" value="R5">
					
						<div class="div_rpt5" style="display:none;">
							<table width='100%' border='0'>
								<tr><td><input type='hidden' name='searchby' id='searchby' value='projectcode'></td></tr>
								<tr><td>Select Project</td></tr>
										
								<tr><td width="150">
										<?php printProjects(3);?>
								</td></tr>
								
								<tr><td><input type='button' name='btn_rpt5' id='btn_rpt5' value='[l&#8801;l]' title='print' class='buttontype1' onclick='submitfrmrpt5()'></td></tr>
							</table>
						</div>
					</form>
<!--				++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++-->	



<!--		++++++++++++++++++++++++++++++++++++block allocation report+++++++++++++++++++++++++++-->
					<form method="post" action="?m=reports&a=BlockAllocationReport" name='frmblockallocation_report' id='frmblockallocation_report'>
						<div class="span_rpt6" style="cursor:pointer;" id='spanrpt'><strong>&#8730; &nbsp;Block Allocation Report</strong></div>
						<input type="hidden" name="rptcode6" id="rptcode6" value="R6">
					
						<div class="div_rpt6" style="display:none;">
							<table width='100%' border='0'>
								<tr><td><input type='hidden' name='searchby' id='searchby' value='projectcode'></td></tr>
								<tr><td>Select Project</td></tr>
										
								<tr><td width="150">
										<?php printProjects(4);?>
								</td></tr>
								
								<tr><td><input type='button' name='btn_rpt6' id='btn_rpt6' value='[l&#8801;l]' title='print' class='buttontype1' onclick='submitfrmrpt6()'></td></tr>
							</table>
						</div>
					</form>
<!--		++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++-->	

<!--		++++++++++++++++++++++++++++++++++++block allocation detail report+++++++++++++++++++++++++++-->
					<form method="post" action="?m=reports&a=BlockAllocationDetailReport" name='frmblockallocationdetail_report' id='frmblockallocationdetail_report'>
						<div class="span_rpt7" style="cursor:pointer;" id='spanrpt'><strong>&#8730; &nbsp;Block Allocation ++ Report</strong></div>
						<input type="hidden" name="rptcode7" id="rptcode7" value="R7">
					
						<div class="div_rpt7" style="display:none;">
							<table width='100%' border='0'>
								<tr><td><input type='hidden' name='searchby' id='searchby' value='projectcode'></td></tr>
								<tr><td>Select Project</td></tr>
										
								<tr><td width="150">
										<?php printProjects(5);?>
								</td></tr>
								
								<tr><td><input type='button' name='btn_rpt7' id='btn_rpt7' value='[l&#8801;l]' title='print' class='buttontype1' onclick='submitfrmrpt7()'></td></tr>
							</table>
						</div>
					</form>
<!--		++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++-->	
						

<!--		++++++++++++++++++++++++++++++++++++    Reminders Report    +++++++++++++++++++++++++++-->
					<form method="post" action="?m=reports&a=ReminderLettersReport" name='frmreminderletters_report' id='frmreminderletters_report'>
						<div class="span_rpt8" style="cursor:pointer;" id='spanrpt_last'><strong>&#8730; &nbsp;Reminder Letters Report</strong></div>
						<input type="hidden" name="rptcode8" id="rptcode8" value="R8">
					
						<div class="div_rpt8" style="display:none;">
							<table width='100%' border='0'>
								<tr><td><input type='hidden' name='searchby' id='searchby' value='projectcode'></td></tr>
								<tr><td>Select Project</td></tr>
										
								<tr><td width="150">
										<?php printProjects('reminders');?>
								</td></tr>
								
								<tr><td><input type='button' name='btn_rpt8' id='btn_rpt8' value='[l&#8801;l]' title='print' class='buttontype1' onclick='submitfrmrpt8()'></td></tr>
							</table>
						</div>
					</form>
<!--		++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++-->	
						
					</td>
				</tr>
				
			</table>
			
	</div>
	</td>
</tr>
</table>
